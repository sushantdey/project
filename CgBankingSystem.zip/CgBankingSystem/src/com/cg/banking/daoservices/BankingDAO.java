package com.cg.banking.daoservices;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public interface BankingDAO{
	Account save(Account account);
	Customer save(Customer customer);
	Transaction save(Transaction transaction);
	Account findAccountNo(long accountNo);
	void update( long accountNo, float f);
	List<Account> findAllAccountDetails();
	List<Transaction> getTransactions(long accountNo);
	List<Transaction> findAllTransactionDetails();
	long findAccountNo1(long id);
}
